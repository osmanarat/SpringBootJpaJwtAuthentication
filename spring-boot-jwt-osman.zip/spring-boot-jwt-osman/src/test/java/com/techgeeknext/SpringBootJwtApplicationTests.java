package com.techgeeknext;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJwtApplicationTests {


	void contextLoads() {
	}

}
